function rotatedCoordinates = rotateCoordinates(xy, theta)
    % Input: xy - 2xN matrix of coordinates, theta - rotation angle in radians
    % Output: rotatedCoordinates - 2xN matrix of rotated coordinates
    
    % Create the rotation matrix
    R = [cos(theta), -sin(theta); sin(theta), cos(theta)];

    % Apply the rotation matrix to the coordinates
    rotatedCoordinates = R * xy;
end
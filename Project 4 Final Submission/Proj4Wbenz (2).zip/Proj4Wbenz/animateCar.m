function animateCar()

    % Assuming calculateWaypoints returns the waypoints
    [x_waypoints, y_waypoints] = updated_calculateWaypoints();

    % Car dimensions
    car_length = 30; % meters
    car_width = 10; % meters

    % Plot the track by running the existing script
    run('plotTrack.m');

    % Initial position of the car's rectangle (centered at start)
    car_x = -car_length / 2;
    car_y = -car_width / 2;

    % Create the patch for the car
    car_patch = patch('XData', [car_x, car_x + car_length, car_x + car_length, car_x], ...
                      'YData', [car_y, car_y, car_y + car_width, car_y + car_width], ...
                      'FaceColor', 'yellow');

    animatedLine = line('Color', 'red', 'LineWidth', 2, 'XData', [], 'YData', []);

    % Animation loop
    for i = 1:length(x_waypoints)-1
        % Calculate direction vector between consecutive waypoints
        direction_vector = [x_waypoints(i+1) - x_waypoints(i), y_waypoints(i+1) - y_waypoints(i)];

        % Update the orientation of the car_patch based on direction vector
        car_angle = atan2(direction_vector(2), direction_vector(1));
        rect = rotateCoordinates([car_x, car_x + car_length, car_x + car_length, car_x; ...
                                  car_y, car_y, car_y + car_width, car_y + car_width], car_angle);

        set(car_patch, 'XData', rect(1,:) + x_waypoints(i), 'YData', rect(2,:) + y_waypoints(i));

        % Update the position of the animatedLine
        set(animatedLine, 'XData', [get(animatedLine, 'XData'), x_waypoints(i)], ...
                          'YData', [get(animatedLine, 'YData'), y_waypoints(i)]);

        % Update the plot
        drawnow;

        % Pause for animation effect
        pause(0.0005);
    end

    % hold off;
end
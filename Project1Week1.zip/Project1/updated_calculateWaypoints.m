
function [x_waypoints, y_waypoints, theta_waypoints] = updated_calculateWaypoints()
    % Track parameters
    straight_length = 900; % Length of the straight sections
    curve_radius = 200;    % Radius of the curved sections
    num_waypoints = 500;   % Total number of waypoints

    % Initialize waypoint arrays
    x_waypoints = zeros(1, num_waypoints);
    y_waypoints = zeros(1, num_waypoints);
    theta_waypoints = zeros(1, num_waypoints);

    % Calculate deltas
    total_track_length = 2 * straight_length + 2 * pi * curve_radius;
    delta_s = total_track_length / num_waypoints;

    % Generate waypoints
    current_s = 0;
    for i = 1:num_waypoints
        if current_s < straight_length
            % Bottom straight
            x_waypoints(i) = current_s;
            y_waypoints(i) = 0;
            theta_waypoints(i) = 0;
        elseif current_s < straight_length + pi * curve_radius
            % Right curve
            theta = (current_s - straight_length) / curve_radius - pi / 2;
            x_waypoints(i) = straight_length + curve_radius * cos(theta);
            y_waypoints(i) = curve_radius * sin(theta) + curve_radius;
            theta_waypoints(i) = theta;
        elseif current_s < 2 * straight_length + pi * curve_radius
            % Top straight
            x_waypoints(i) = 2 * straight_length + pi * curve_radius - current_s;
            y_waypoints(i) = 2 * curve_radius;
            theta_waypoints(i) = pi;
        else
        % Left curve
        theta = (current_s - (2 * straight_length + pi/2 * curve_radius)) / curve_radius;
        x_waypoints(i) = curve_radius * cos(theta);
        y_waypoints(i) = 400 - (curve_radius - curve_radius * sin(theta)); % Shifted up by 400 meters
        theta_waypoints(i) = theta;
        end

        current_s = current_s + delta_s;
        % Correcting the final waypoint to ensure a closed loop
        if i == num_waypoints
            x_waypoints(i) = x_waypoints(1);
            y_waypoints(i) = y_waypoints(1);
            theta_waypoints(i) = theta_waypoints(1);
        end
    end
    
x_waypoints(end) = x_waypoints(1);
y_waypoints(end) = y_waypoints(1);
theta_waypoints(end) = theta_waypoints(1);

end




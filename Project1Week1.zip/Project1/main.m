% Run the plotTrack script to plot the track
run('plotTrack.m');

% After plotting the track, calculate and plot the waypoints
[waypoints_x, waypoints_y, theta_waypoints] = updated_calculateWaypoints();

% Plot waypoints - This can be commented out if you only want the animation
hold on; % Keeps the current plot
plot(waypoints_x, waypoints_y, 'go', 'MarkerSize', 5, 'MarkerFaceColor', 'g'); % Plot waypoints as green dots


run('animateCar.m');

hold off; 

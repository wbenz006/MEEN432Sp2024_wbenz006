
function animateCar()

    % Assuming calculateWaypoints returns the waypoints and their orientations
    [x_waypoints, y_waypoints, theta_waypoints] = updated_calculateWaypoints();

    % Car dimensions
    car_length = 15; % meters
    car_width = 10; % meters

    % Create figure
    %figure;
   % hold on;
    %axis equal;
    %grid on;
    %xlabel('Distance in meters');
    %ylabel('Distance in meters');
    %title('Oval Track with Moving Car');

    % Plot the track by running the existing script
    run('plotTrack.m');

    % Initial position of the car's rectangle (centered at start)
    car_x = -car_length / 2;
    car_y = -car_width / 2;

    % Create the patch for the car
    car_patch = patch('XData', [car_x, car_x + car_length, car_x + car_length, car_x], ...
                      'YData', [car_y, car_y, car_y + car_width, car_y + car_width], ...
                      'FaceColor', 'yellow');

animatedLine = line('Color', 'red', 'LineWidth', 2, 'XData', [], 'YData', []);

    % Animation loop
    for i = 1:length(x_waypoints)
        % Update the position of the car
        car_angle = theta_waypoints(i);
        R = [cos(car_angle), -sin(car_angle); sin(car_angle), cos(car_angle)];
        rect = R * [car_x, car_x + car_length, car_x + car_length, car_x; ...
                    car_y, car_y, car_y + car_width, car_y + car_width];
                
        set(car_patch, 'XData', rect(1,:) + x_waypoints(i), 'YData', rect(2,:) + y_waypoints(i));

        newX = get(car_patch, 'XData');
    newY = get(car_patch, 'YData');
    currentX = mean(newX); % Assuming the car's patch is centered on its position
    currentY = mean(newY);
    xData = get(animatedLine, 'XData');
    yData = get(animatedLine, 'YData');
    set(animatedLine, 'XData', [xData currentX], 'YData', [yData currentY]);

        % Update the plot
        drawnow;
        
        % Pause for animation effect
        pause(0.005);
    end

   % hold off;
end
